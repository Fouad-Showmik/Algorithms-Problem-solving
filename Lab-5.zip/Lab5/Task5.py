#!/usr/bin/env python
# coding: utf-8

# In[4]:


def make_graph(a):
    dct = {}
    for i in range(len(a)):
        x = a[i].split()
        k = int(x[0])
        v = int(x[1])
        w = int(x[2])
        if k not in dct.keys():
            if v == k and len(a) == 1:
                dct[k] = []
            else:
                if v != k:
                    dct[k] = [[v, w]]
        else:
            p = [v, w]
            dct[k].append(p)
    return dct


def dijkstra(graph, s, flag, vert_count):
    parent = [None] * (1 + vert_count)
    dis = [-1] * (1 + vert_count)
    parent[s] = 'pi'
    dis[s] = 0
    queue = []
    queue.append((dis[s], s))
    queue.sort(reverse=True)
    while len(queue) > 0:
        dist, m = queue.pop()
        if flag[m] == 1:
            continue
        flag[m] = 1
        if m in graph.keys():
            for i in graph[m]:
                store = [i][0]
                alt = dist + store[1]
                land = store[0]
                if alt > dis[land]:
                    dis[land] = alt
                    parent[land] = m
                    queue.append((dis[land], land))
    store = []
    x = vert_count
    store.append(x)
    while x != s:
        store.append(parent[x])
        x = parent[x]
    maxPath = store[::-1]
    return graph, maxPath, vert_count


output = open('output5.txt', 'w')


def min_path(graph, path, vert_count, s):
    store = 10 ** 10
    if len(path) < vert_count:
        output.write('-1 ')
    for i in range(0, path.index(s)):
        if path[i] == s:
            output.write('0 ')
        if path[i] in graph.keys() and i + 1 < len(path) - 2:
            if graph[path[i]][i + 1][1] < store:
                store = graph[path[i]][i + 1][1]
        elif path[i] in graph.keys():
            if graph[path[i]][0][1] < store:
                store = graph[path[i]][0][1]
    if store == 10 ** 10:
        store = 0
    if s == vert_count:
        output.write(f'{store}\n')
    else:
        output.write(f'{store} ')


input_05 = open('input5.txt').readlines()
p = int(input_05[0])
s = []
vert = []
edg = []
for i in range(1, len(input_05)):
    x = input_05[i].split()
    if len(x) == 1:
        s.append(x)
    elif len(x) == 2:
        vert.append(x)
    elif len(x) > 2:
        edg.append(x)


def call():
    for i in vert:
        n = int(i[0])
        m = int(i[1])
        newSource = s.pop(0)
        store = ""
        store_2 = []
        for j in range(m):
            x = edg.pop(0)
            for k in x:
                store += k + " "
            store_2.append(store)
            store = ''
        g = make_graph(store_2)
        visit = [0] * (len(g) + 2)
        newGraph, newPath, count = dijkstra(g, int(newSource[0]), visit, n)
        sp = sorted(newPath)
        for i in sp:
            min_path(newGraph, newPath, count, i)


call()


# In[ ]:




