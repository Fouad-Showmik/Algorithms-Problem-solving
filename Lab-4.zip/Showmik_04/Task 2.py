#!/usr/bin/env python
# coding: utf-8

# In[2]:


with open('input2.txt','r') as file_in:
    N=file_in.readline().split()
    node=int(N[0])
    edge=int(N[1])
    with open('output2.txt','w') as file_out:
        dic={}
        for i in range(node+1):
            if i not in dic:
                dic[i]=[]
        
        for i in range(edge):
            x=file_in.readline().split()
            node_1=int(x[0])
            node_2=int(x[1])
            if node_1 not in dic:
                dic[node_1]=None
            else:
                dic[node_1].append(node_2)
        print(dic)
        visited = []
        queue = []

        def bfs(visited, dic, node):
            visited.append(node)
            queue.append(node)

            while queue:
                start = queue.pop(0)
                file_out.write(f'{start} ')
                for i in dic[start]:
                    if i not in visited:
                        visited.append(i)
                        queue.append(i)
        bfs(visited,dic,1)


# In[ ]:





# In[ ]:




