#!/usr/bin/env python
# coding: utf-8

# In[2]:


class PQ:
    def __init__(self, queue, period):
        self.queue = queue
        self.period = period

    def ins(self, val, val1):
        self.queue.append(val)
        self.period.append(val1)

    def pop(self):
        c = 0
        if len(self.queue) != 0:
            for i in range(len(self.queue)):
                if self.period[i] < self.period[c]:
                    c = i
            value = self.queue[c]
            value1 = self.period[c]
            del self.queue[c]
            del self.period[c]
            return (value, value1)
        else:
            return "empty"

    def delete(self, idx):
        del self.queue[idx]
        del self.period[idx]

    def display(self):
        return self.queue, self.period


def dijkstra(d):
    va = obj.pop()
    if va == "empty":
        return (p, t, child, parent)
    else:
        x, y = va
        p.append(x)
        t.append(y)
        for values in d[x]:
            a, b = obj.display()
            if values[0:-1] not in p:
                if values[0:-1] not in a:
                    parent.append(x)
                    child.append(values[0:-1])
                    obj.ins(values[0:-1], y + int(values[-1]))
                elif values[0:-1] in a:
                    m = a.index(values[0:-1])
                    if int(values[-1]) + y < b[m]:
                        obj.delete(m)
                        parent.append(x)
                        child.append(values[0:-1])
                        obj.ins(values[0:-1], y + int(values[-1]))
                else:
                    pass
        return dijkstra(d)


file = open("input1.txt", "r")
file2 = open("output1.txt", "w")
x = file.readlines()
d = {}
visited = []
for i in range(0, len(x)):
    x[i] = x[i].strip()
    a, b, c = x[i].split()
    if b not in visited:
        visited.append(b)
        d[b] = [a + str(c)]
    else:
        d[b].append(a + str(c))
    if a not in visited:
        visited.append(a)
        d[a] = [b + str(c)]
    else:
        d[a].append(b + str(c))
p = []
t = []
que1 = []
child = []
parent = []
time1 = []
obj = PQ(que1, time1)
obj.ins('MOGHBAZAR', 0)
ans1, ans2, ans3, ans4 = dijkstra(d)


end = "Motijheel"
start = "Motijheel"
time = ans2[ans1.index("Motijheel")]
file2.write(f"Shortest path is: {start} ")
while start != "MOGHBAZAR":
    start = ans4[ans3.index(start)]
    file2.write(f"{start} ")
file2.write(f"\ntime taken is {time}")
file.close()
file2.close()


# In[ ]:




