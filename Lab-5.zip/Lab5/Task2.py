#!/usr/bin/env python
# coding: utf-8

# In[2]:


from queue import PriorityQueue


class make_graph:
    def __init__(self, number):
        self.vert = number
        self.edg = [[-1 for i in range(number)] for j in range(number)]
        self.flag = []

    def add_edge(self, u, v, w):
        self.edg[u][v] = w
        self.edg[v][u] = w


def dijkstra_algo(graph, s):
    dis = [10 ** 10] * graph.vert
    dis[s] = 0
    queue = PriorityQueue()
    queue.put((dis[s], s))

    while not queue.empty():
        dist, m = queue.get()
        graph.flag.append(m)
        for j in range(graph.vert):
            if j not in graph.flag and graph.edg[m][j] != -1:
                if dis[j] > dis[m] + graph.edg[m][j]:
                    dis[j] = dis[m] + graph.edg[m][j]
                    queue.put((dis[j], j))
    return dis[m]


T = open('input2.txt', 'r').read().splitlines()

p = int(T[0])
vert = []
edg = []
for i in range(1, len(T)):
    x = T[i].split()
    if len(x) == 2:
        vert.append(x)
    if len(x) > 2:
        edg.append(x)

output = open('output2.txt', 'w')


def call():
    for i in vert:
        store = int(i[1])
        a = make_graph(store + 2)
        for i in range(store):
            m = edg.pop(0)
            a.add_edge(int(m[0]), int(m[1]), int(m[2]))
        final = dijkstra_algo(a, 1)
        output.write(f"{final}\n")
call()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




