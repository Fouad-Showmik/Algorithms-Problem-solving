#!/usr/bin/env python
# coding: utf-8

# In[6]:


# Task 04
input_4 =open('input4.txt', 'r')
output=open('output4.txt','w')
num = input_1.read().split('\n')

for i in range(len(num)):
    flag = 0
    num[i] = num[i].split()
    num[i][0], num[i][1] = int(num[i][0]), int(num[i][1])

    if num[i][0] == num[i][1]:
        pass

    else:
        for j in range(num[i][0], num[i][1]+1):
            root = j**0.5
      
            if root == int(root):
                flag += 1

        output.write(f'{flag}')
input_4.close()
output.close()


# In[16]:


# Task 04
input_4 = open('input4.txt', 'r')
output=open('output4.txt','w')
num = input_4.read().split('\n')

for x in range(len(num)):
    flag = 0
    num[x] = num[x].split()
    num[x][0], num[x][1] = int(num[x][0]), int(num[x][1])

    if num[x][0] == num[x][1]:
        pass

    else:
        for y in range(num[x][0], num[x][1]+1):
            root = y**0.5
      
            if root == int(root):
                flag += 1
        output.write(f'{flag}\n')
input_4.close()
output.close()


# In[ ]:




