#!/usr/bin/env python
# coding: utf-8

# In[1]:


with open('input4.txt','r') as file_in:
    N=file_in.readline().split()
    node=int(N[0])
    edge=int(N[1])
    with open('output4.txt','w') as file_out:
        dic={}
        for i in range(node+1):
            if i not in dic:
                dic[i]=[]
        
        for i in range(edge):
            x=file_in.readline().split()
            node_1=int(x[0])
            node_2=int(x[1])
            if node_1 not in dic:
                dic[node_1]=None
            else:
                dic[node_1].append(node_2)
        color={}
        parent={}
        for u in dic.keys():
            color[u]='w'
            parent[u]=None
        def dfs(u,color,parent):
            color[u]='g'
            for v in dic[u]:
                if color[v]=='w':
                    cycle=dfs(v,color,parent)
                    if cycle==True:
                        return True
                elif color[v]=='g':
                    return True
            color='b'
            return False
        is_cycle=False
        for u in dic.keys():
            if color[u]=='w':
                is_cycle=dfs(u,color,parent)
                if is_cycle==True:
                    break
        if is_cycle==True:
            file_out.write(f'YES')
        else:
            file_out.write(f'NO')

            
            
#(a) The given graph will form a tree-
#   (1) Connected
#   (2) Edges = (n-1) [n=Total number of vertices]
#   (3) No cycle 

#(b) First I'll run a single DFS from any node (actually, any node which is contained in the non-bipartite connected component) and assign colors as it goes. The first time I'll find a back-edge connecting two vertices of the same color. Then I'll unwind the node stack between these two vertices. Thus, I'll find the odd length cycle of the graph.


# In[ ]:





# In[ ]:




