#!/usr/bin/env python
# coding: utf-8

# In[4]:


with open('input2.txt', 'r') as file_in:
    activity, man = map(int, file_in.readline().split())
    work = []
    flag_1 = []
    flag_2 = []
    with open('output2.txt', 'w') as file_out:
        for i in range(activity):
            t1, t2 = file_in.readline().split()
            work.append([int(t1), int(t2)])

        work.sort()
        flag_1.append(work[0])
        temp = flag_1[0][1]

        for j in range(1, len(work)):

            if work[j][0] > temp:
                flag_1.append(work[j])
                temp = work[j][1]

            elif temp < work[j][1] and work[j] not in flag_2:
                flag_2.append(work[j])
        file_out.write(f'{(len(flag_1) + len(flag_2))}')


# In[ ]:




