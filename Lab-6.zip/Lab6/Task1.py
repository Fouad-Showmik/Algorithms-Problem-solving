#!/usr/bin/env python
# coding: utf-8

# In[2]:


with open('input1.txt', 'r') as file_in:
    assign = int(file_in.readline())
    inter = []
    with open('output1.txt', 'w') as file_out:
        for i in range(assign):
            t1, t2 = file_in.readline().split()
            inter.append([int(t1), int(t2)])

        for j in range(len(inter)):
            for k in range(j, len(inter)):
                if inter[j][1] > inter[k][1]:
                    inter[j], inter[k] = inter[k], inter[j]
        done = [inter[0]]
        flag = done[0][1]
        for l in range(1, len(inter)):
            if flag <= inter[l][0]:
                done.append(inter[l])
                flag = inter[l][1]
                
        file_out.write(f'{len(done)}\n')
        for m in done:
            file_out.write(f'{m}\n')


# In[ ]:




