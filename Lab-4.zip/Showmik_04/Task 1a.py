#!/usr/bin/env python
# coding: utf-8

# In[4]:


with open('input1a.txt','r') as file_in:
    n=file_in.readline().split()
    with open('output1a.txt','w') as file_out:
        N=[int(i) for i in n]
        nodes=N[0]
        edges=N[1]
        lst=[]
        new=[]
        for k in range(nodes+1):
            new.append(0)
        for i in range(nodes+1):
            lst.append([int(i) for i in new])
        for j in range(edges):
            x=file_in.readline().split()
            y=[int(i) for i in x]
            a=y[0]
            b=y[1]
            c=y[2]
            for i in range(len(lst)):
                if i==a:
                    lst[a][b]=c
                else:
                    continue
        for i in lst:
            file_out.write(f'{i}\n')


# In[ ]:




