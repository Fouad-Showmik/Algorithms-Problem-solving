#!/usr/bin/env python
# coding: utf-8

# In[12]:


with open('input3.txt','r') as file_in:
    number = int(file_in.readline())
    with open('output3.txt','w') as file_out:
        task = file_in.readline().split()
        activities = [int(i) for i in task]
        activities_pattern = file_in.readline()
        activities.sort()
        Jack = []
        Jill = []
        flag = ''
        jack_time = 0
        jill_time = 0
        for alpha in activities_pattern:
            if alpha == 'J':
                x = activities.pop(0)
                jack_time += x
                Jack.append(x)
                flag += str(x)
            else:
                y = Jack.pop()
                Jill.append(y)
                flag += str(y)
                jill_time += y
        file_out.write(f'{flag}\nJack will work for {jack_time} hours\nJill will work for {jill_time} hours')


# In[ ]:




