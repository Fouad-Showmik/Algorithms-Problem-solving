#!/usr/bin/env python
# coding: utf-8

# In[8]:


with open('input1b.txt','r') as file_in:
    a=file_in.readline().split()          
    node=int(a[0])
    edge=int(a[1])
    with open('output1b.txt','w') as file_out:
        dic={}
        for i in range(edge):
            b=file_in.readline().split()
            for j in range(node+1):
                if j not in dic:
                    dic[j]=""
                if int(b[0])==j:
                    for k in range(node+1):
                        if k==int(b[1]):
                            if j not in dic:
                                dic[j]="({},{}) ".format(k,b[2].strip('\n'))
                            else:
                                dic[j]+="({},{})".format(k,b[2].strip('\n'))
        for k,v in dic.items():
            file_out.write(f'{k} : {v}\n')


# In[ ]:




