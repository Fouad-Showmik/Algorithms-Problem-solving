#!/usr/bin/env python
# coding: utf-8

# In[5]:


with open('input5.txt','r') as file_in:
    a=file_in.readline().split()
    node=int(a[0])
    edge=int(a[1])
    des=int(a[2])
    dic_1={}
    dic_2={}
    final={}
    for i in range(1,node+1):
        dic_1[i]=[]
        dic_2[i]=0
        final[i]=0
    with open('output5.txt','w') as file_out:
        for j in range(edge):
            b=file_in.readline().split()
            x = int(b[0])
            y = int(b[1])
            if x in dic_1.keys():
                if y not in dic_1[x]:
                    dic_1[x].append(int(b[1]))
            if y in dic_1.keys():
                if x not in dic_1[y]:
                    dic_1[y].append(x)
        queue = [1]
        visited = []
        while queue:
            start = queue.pop(0)
            visited.append(start)
            for i, j in dic_1.items():
                if i == start:
                    for k in dic_1[i]:
                        if k not in queue:
                            if k not in visited:
                                queue.append(k)

                        if dic_2[k] == 0:
                            if k != 1:
                                dic_2[k] = (dic_2[start] + 1)
                                final[k] = i
        path = []
        time = des
        while time != 0:
            for key, value in final.items():
                if key == time:
                    path.append(key)
                    time = value
                    break
        file_out.write(f'Time: {dic_2[des]}\n')
        file_out.write(f'Shortest Path: ')
        for i in range(len(path)-1,-1,-1):
            file_out.write(f'{path[i]} ')


# In[ ]:





# In[ ]:




